function [f,P1] = FFT_transform(s,SampleFreq)


if( mod(length(s),2) ~= 0 ) % We need even long intervall  

    s = s(1:end-1);
    
end
    
    
L = length(s); % Length of the intervall
S = fft(s);

P2 = abs(S/L);  % Compute the two-sided spectrum P2
P1 = P2(1:L/2+1);  % Compute the one-sided spectrum P1
P1(2:end-1) = 2*P1(2:end-1);

f = SampleFreq*(0:(L/2))/L;

end

