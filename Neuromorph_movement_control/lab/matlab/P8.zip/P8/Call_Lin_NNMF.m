function Call_Lin_NNMF(number_of_synergies, H_order)

file_name = strcat(pwd,'/Plot_Data/EMG_Envelopes.mat'); load (file_name); % load EMG_Envelopes
file_name = strcat(pwd,'/Plot_Data/EMG_Envelopes_mean.mat'); load (file_name); % load EMG_Envelopes_mean

[number_muscles number_points] = size(EMG_Envelopes);

%% Receive H from GUI
W = rand(number_muscles,number_of_synergies);
for i = 1:number_of_synergies
    H(i,1:number_points) = EMG_Envelopes(str2num(cell2mat(H_order(i))),:);
end

for i = 1:number_muscles
    V_aux(i,1:length(EMG_Envelopes)) = EMG_Envelopes(i,:);
end

V=V_aux;
EMG_0 = V;

EMG_0_mean = EMG_Envelopes_mean(1:number_muscles,:);

new_path = strcat(pwd,'/Plot_Data/EMG_0.mat'); save(new_path,'EMG_0'); % Save Raw_EMG
new_path = strcat(pwd,'/Plot_Data/EMG_0_mean.mat'); save(new_path,'EMG_0_mean'); % Save Raw_EMG
clearvars -except V W H number_muscles number_of_synergies EMG_Envelopes

% Winit is a matrix (m x n), with the muscle weighttings for each muscle in
% each module
% n (number of modules) is the number of muscles
Winit = W;

% Hinit is a matrix (n x t), with the ativation time profile in each module
Hinit = H;
  
% Parameters for the toolbox that I found
tol=0;
timelimit=1000;
maxiter=100;

% Toolbox that calculates the final matrices
[W,H] = nmf(V,Winit,Hinit,tol,timelimit,maxiter);

maximos_W = max(W);
for i=1:length(maximos_W)
    W(:,i) = W(:,i) / maximos_W(i);
    H(i,:) = H(i,:) * maximos_W(i);
end

V=W*H;

[a b] = size(H);
for j=1:a
    for i=1:b/101
        aux_H(i,1:101)=H(j,i*101-100:i*101);
    end
    H_mean(j,1:101)=mean(aux_H);
end


[a b] = size(EMG_Envelopes);
for j=1:a
    for i=1:b/101
        aux_EMG_0_mean(i,1:101)=EMG_Envelopes(j,i*101-100:i*101);
    end
    EMG_0_mean(j,1:101)=mean(aux_EMG_0_mean);
end


for i=1:number_of_synergies
    [maximo, order_synergies(i)] = max(H_mean(i,:));
end

aux_H_mean = H_mean;
aux_H = H;
aux_W = W;

V_mean=W*H_mean;

[B,IX] = sort(order_synergies);

for i=1:number_of_synergies
    H_mean(i,:) = aux_H_mean(IX(i),:);
    H(i,:) = aux_H(IX(i),:);
    W(:,i) = aux_W(:,IX(i));
end

new_path = strcat(pwd,'/Plot_Data/V.mat'); save(new_path,'V'); % Save Raw_EMG
new_path = strcat(pwd,'/Plot_Data/V_mean.mat'); save(new_path,'V_mean'); % Save Raw_EMG
new_path = strcat(pwd,'/Plot_Data/W.mat'); save(new_path,'W'); % Save Raw_EMG
new_path = strcat(pwd,'/Plot_Data/H.mat'); save(new_path,'H'); % Save Raw_EMG
new_path = strcat(pwd,'/Plot_Data/H_mean.mat'); save(new_path,'H_mean'); % Save Raw_EMG