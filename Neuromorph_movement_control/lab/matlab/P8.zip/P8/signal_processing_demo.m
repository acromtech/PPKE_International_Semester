% Basic signal Processing methods

clear all;


emg_data  = table2array(load('right_arm_emg.mat').m);

channel = 1;
sampling_rate = 1200;
data_length = length(emg_data);



%% Show raw data
[f, P1] = FFT_transform(emg_data(3:end,channel),sampling_rate);

% 
figure(1);
subplot(2,1,1);plot(emg_data(:,channel));
title('Time domain of the signal');
xlim([0,data_length]);
xlabel('num of sample');
ylabel('voltage [V]');

subplot(2,1,2);plot(f,P1);
title('Frequency domain of the signal');
xlim([0,sampling_rate/4]);
xlabel('frequency [hz]');
ylabel('Amplitude');

%% Calc filtered data

[a,b] = butter(4, [20 500]/(sampling_rate/2),'bandpass');
emg_data_b = filter(a,b,emg_data(3:end,channel));

%% Show filtered data (1)

[f, P1] = FFT_transform(emg_data_b,sampling_rate);

figure(2);
subplot(2,1,1);plot(emg_data_b);
title('Time domain of the signal');
xlim([0,data_length]);
xlabel('num of sample');
ylabel('voltage [V]');

subplot(2,1,2);plot(f,P1);
title('Frequency domain of the signal');
xlim([0,sampling_rate/4]);
xlabel('frequency [hz]');
ylabel('Amplitude');


%% Fileter out enviromental 50 Hz and its upper overharmonic
[a,b] = butter(4, [49.5 50.5]/(sampling_rate/2),'stop');
emg_data_bf = filter(a,b,emg_data_b);

[a,b] = butter(4, [99.5 100.5]/(sampling_rate/2),'stop');
emg_data_bf = filter(a,b,emg_data_bf);

[a,b] = butter(4, [149.5 150.5]/(sampling_rate/2),'stop');
emg_data_bf = filter(a,b,emg_data_bf);

%% Show filtered data (2)

[f, P1] = FFT_transform(emg_data_bf,sampling_rate);

figure(3);
subplot(2,1,1);plot(emg_data_bf);
title('Time domain of the signal');
xlim([0,data_length]);
xlabel('num of sample');
ylabel('voltage [V]');

subplot(2,1,2);plot(f,P1);
title('Frequency domain of the signal');
xlim([0,sampling_rate/4]);
xlabel('frequency [hz]');
ylabel('Amplitude');

%% Calculate mooving average

movRMS = dsp.MovingRMS(50);
PreprocessedData = movRMS(emg_data_bf);
[f, P1] = FFT_transform(PreprocessedData,sampling_rate);

figure(4);
subplot(2,1,1);plot(PreprocessedData);
title('Time domain of the signal');
xlim([0,data_length]);
xlabel('num of sample');
ylabel('voltage [V]');

subplot(2,1,2);plot(f,P1);
title('Frequency domain of the signal');
xlim([0,sampling_rate/4]);
xlabel('frequency [hz]');
ylabel('Amplitude');
