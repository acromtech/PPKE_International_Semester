% kinect
% in reality: we are using realsense

close all;
clear;
clc;

% loading the image-arrays to work with:
load('dog.mat', 'dog_RGB', 'dog_DEPTH');
load('elephant.mat', 'elephant_RGB', 'elephant_DEPTH');

figure;
subplot(1, 2, 1);
imshow(dog_RGB);
title('dog - RGB');
subplot(1, 2, 2);
imagesc(dog_DEPTH(:, :), [0, 2^11]); % 2^11=2048, the color palette of imagesc will be trimmed around 2 meters
title('dog - DEPTH');
axis equal;
set(gca, 'XLim', [0, 640]);
set(gca, 'YLim', [0, 480]);

figure;
subplot(1, 2, 1);
imshow(elephant_RGB);
title('elephant - RGB');
subplot(1, 2, 2);
imagesc(elephant_DEPTH(:, :), [0, 2^11]);
title('elephant - DEPTH');
axis equal;
set(gca, 'XLim', [0, 640]);
set(gca, 'YLim', [0, 480]);


% and now please 'fuse' the two RGB-images on the basis of the
% depth-values:











